#!/usr/bin/env python3
"""Create the two requested charts from the same cleaned SQLite order data."""

from __future__ import annotations

import argparse
import sqlite3
from pathlib import Path

import matplotlib

matplotlib.use("Agg")

import matplotlib.pyplot as plt

from clean_and_eda import DEFAULT_DB, load_order_data, prepare_clean_orders


REPO_ROOT = Path(__file__).resolve().parents[1]
VISUALIZATION_DIR = REPO_ROOT / "visualizations"


def create_visualizations(database_path: Path, output_dir: Path) -> None:
    if not database_path.exists():
        raise FileNotFoundError(
            f"SQLite database not found at {database_path}. "
            "Run the schema and seed commands in the README first."
        )
    with sqlite3.connect(database_path) as connection:
        raw = load_order_data(connection)
    clean, _quality = prepare_clean_orders(raw)
    output_dir.mkdir(parents=True, exist_ok=True)

    payment_summary = (
        clean.groupby("payment_method", sort=True)
        .agg(order_count=("order_id", "count"), returned_count=("returned", "sum"))
        .reset_index()
    )
    payment_summary["return_rate_pct"] = (
        payment_summary["returned_count"] / payment_summary["order_count"] * 100
    )

    fig, ax = plt.subplots(figsize=(9, 5.2), constrained_layout=True)
    bars = ax.bar(
        payment_summary["payment_method"],
        payment_summary["return_rate_pct"],
        color="#61A9BD",
        width=0.62,
    )
    ax.set_title("Return rate by payment method", loc="left", weight="bold", pad=14)
    ax.set_ylabel("Returned orders (%)")
    ax.set_xlabel("Payment method")
    ax.set_ylim(0, max(5, float(payment_summary["return_rate_pct"].max()) * 1.2))
    ax.yaxis.grid(True, color="#DDE4E7", linewidth=0.8)
    ax.set_axisbelow(True)
    ax.spines[["top", "right", "left"]].set_visible(False)
    ax.tick_params(axis="y", length=0)
    for bar, row in zip(bars, payment_summary.to_dict(orient="records")):
        ax.annotate(
            f"{row['return_rate_pct']:.1f}%  ·  n={row['order_count']}",
            (bar.get_x() + bar.get_width() / 2, bar.get_height()),
            xytext=(0, 5),
            textcoords="offset points",
            ha="center",
            va="bottom",
            fontsize=9,
        )
    fig.savefig(output_dir / "return_rate_by_payment.png", dpi=180, facecolor="white")
    plt.close(fig)

    monthly = (
        clean.groupby("month", sort=True)
        .agg(
            retained_revenue_inr=("retained_revenue_inr", "sum"),
            returned_order_value_inr=("returned_order_value_inr", "sum"),
        )
        .reset_index()
    )

    fig, ax = plt.subplots(figsize=(10, 5.5), constrained_layout=True)
    ax.plot(
        monthly["month"],
        monthly["retained_revenue_inr"],
        marker="o",
        linewidth=2.5,
        color="#44986D",
        label="Retained revenue",
    )
    ax.plot(
        monthly["month"],
        monthly["returned_order_value_inr"],
        marker="o",
        linewidth=2,
        color="#D8524F",
        label="Returned order value",
    )
    ax.set_title("Monthly revenue after discounts and returns", loc="left", weight="bold", pad=14)
    ax.set_ylabel("Order value (INR)")
    ax.set_xlabel("Order month")
    ax.yaxis.grid(True, color="#DDE4E7", linewidth=0.8)
    ax.set_axisbelow(True)
    ax.spines[["top", "right", "left"]].set_visible(False)
    ax.tick_params(axis="y", length=0)
    ax.legend(frameon=False, loc="upper left")
    ax.set_xticks(range(len(monthly)))
    ax.set_xticklabels(monthly["month"], rotation=0)
    fig.savefig(output_dir / "monthly_revenue_trend.png", dpi=180, facecolor="white")
    plt.close(fig)

    print(f"Wrote both chart files to {output_dir}.")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--db", type=Path, default=DEFAULT_DB)
    parser.add_argument("--output-dir", type=Path, default=VISUALIZATION_DIR)
    args = parser.parse_args()
    create_visualizations(args.db, args.output_dir)


if __name__ == "__main__":
    main()
