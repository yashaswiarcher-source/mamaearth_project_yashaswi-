#!/usr/bin/env python3
"""Clean the SQLite order data and write computed findings for the narrator."""

from __future__ import annotations

import argparse
import json
import sqlite3
from pathlib import Path
from typing import Any

import pandas as pd


REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DB = REPO_ROOT / "data" / "mamaearth.db"
FINDINGS_PATH = REPO_ROOT / "narrator" / "findings.json"

BUSINESS_KEY = [
    "customer_id",
    "product_id",
    "order_date",
    "quantity",
    "discount_pct",
    "payment_method",
    "rating",
    "returned",
]


def load_order_data(connection: sqlite3.Connection) -> pd.DataFrame:
    """Read the relational store, not the source CSVs."""
    query = """
        SELECT
            o.order_id,
            o.customer_id,
            c.city,
            c.city_tier,
            c.acquisition_source,
            o.product_id,
            p.product_name,
            p.category,
            p.price,
            o.order_date,
            o.quantity,
            o.discount_pct,
            o.payment_method,
            o.rating,
            o.returned
        FROM orders AS o
        JOIN customers AS c ON c.customer_id = o.customer_id
        JOIN products AS p ON p.product_id = o.product_id
        ORDER BY o.order_id
    """
    frame = pd.read_sql_query(query, connection)
    if frame.empty:
        raise ValueError("The SQLite order query returned no rows. Seed the database first.")
    return frame


def prepare_clean_orders(raw: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Apply documented cleaning rules and add order-value measures."""
    frame = raw.copy()
    raw_count = len(frame)

    for column in ("price", "quantity", "discount_pct", "rating", "returned"):
        frame[column] = pd.to_numeric(frame[column], errors="coerce")

    if frame[["order_id", "customer_id", "product_id", "order_date"]].isna().any().any():
        raise ValueError("Required order identifiers or dates are missing.")
    if frame["order_id"].duplicated().any():
        raise ValueError("order_id must be unique in the raw SQLite table.")
    if frame["quantity"].isna().any() or (frame["quantity"] <= 0).any():
        raise ValueError("Quantity must be present and greater than zero.")
    if frame["price"].isna().any() or (frame["price"] < 0).any():
        raise ValueError("Product prices must be present and non-negative.")
    if frame["returned"].isna().any() or not frame["returned"].isin([0, 1]).all():
        raise ValueError("Returned values must be 0 or 1.")

    frame["payment_method"] = frame["payment_method"].astype("string").str.strip().str.upper()
    if frame["payment_method"].isna().any() or not frame["payment_method"].isin(
        {"COD", "CARD", "UPI"}
    ).all():
        raise ValueError("Unexpected or missing payment method in source data.")

    duplicate_mask = frame.duplicated(subset=BUSINESS_KEY, keep="first")
    duplicate_rows_removed = int(duplicate_mask.sum())
    frame = frame.loc[~duplicate_mask].copy().reset_index(drop=True)

    missing_discount_count = int(frame["discount_pct"].isna().sum())
    missing_rating_count = int(frame["rating"].isna().sum())
    discount_median = float(frame["discount_pct"].median())
    rating_median = float(frame["rating"].median())
    if pd.isna(discount_median) or pd.isna(rating_median):
        raise ValueError("Cannot impute a field whose cleaned values are all missing.")

    frame["discount_pct"] = frame["discount_pct"].fillna(discount_median)
    frame["rating"] = frame["rating"].fillna(rating_median)
    if not frame["discount_pct"].between(0, 100).all():
        raise ValueError("Discount percentages must be between 0 and 100.")
    if not frame["rating"].between(1, 5).all():
        raise ValueError("Ratings must be between 1 and 5.")

    frame["order_date"] = pd.to_datetime(frame["order_date"], errors="raise")
    frame["month"] = frame["order_date"].dt.strftime("%Y-%m")
    frame["returned"] = frame["returned"].astype(int)
    frame["quantity"] = frame["quantity"].astype(int)

    frame["list_price_order_value_inr"] = frame["price"] * frame["quantity"]
    frame["discounted_order_value_inr"] = (
        frame["list_price_order_value_inr"] * (1 - frame["discount_pct"] / 100)
    ).round(2)
    frame["returned_order_value_inr"] = frame["discounted_order_value_inr"].where(
        frame["returned"].eq(1), 0.0
    )
    frame["retained_revenue_inr"] = frame["discounted_order_value_inr"].where(
        frame["returned"].eq(0), 0.0
    )

    unusual_quantity = frame["quantity"] > 3
    frame["unusual_quantity"] = unusual_quantity
    quality = {
        "source_order_count": int(raw_count),
        "duplicate_rows_removed": duplicate_rows_removed,
        "clean_order_count": int(len(frame)),
        "missing_discount_rows_imputed": missing_discount_count,
        "missing_rating_rows_imputed": missing_rating_count,
        "discount_pct_median_used": discount_median,
        "rating_median_used": rating_median,
        "unusual_quantity_rows_retained": int(unusual_quantity.sum()),
        "unusual_quantity_order_ids": frame.loc[unusual_quantity, "order_id"].tolist(),
    }
    return frame, quality


def percentage(numerator: float, denominator: float) -> float:
    if denominator == 0:
        return 0.0
    return round(float(numerator) / float(denominator) * 100, 2)


def _table_records(
    frame: pd.DataFrame,
    group_columns: str | list[str],
) -> list[dict[str, Any]]:
    grouped = frame.groupby(group_columns, dropna=False, sort=True)
    records: list[dict[str, Any]] = []
    for key, group in grouped:
        if not isinstance(key, tuple):
            key = (key,)
        record: dict[str, Any] = dict(zip(
            [group_columns] if isinstance(group_columns, str) else group_columns,
            key,
        ))
        returned_count = int(group["returned"].sum())
        order_count = int(len(group))
        record["order_count"] = order_count
        record["returned_order_count"] = returned_count
        record["return_rate_pct"] = percentage(returned_count, order_count)
        record["returned_order_value_inr"] = round(
            float(group["returned_order_value_inr"].sum()), 2
        )
        records.append(record)
    return records


def build_findings(
    clean: pd.DataFrame, quality: dict[str, Any]
) -> dict[str, Any]:
    returned_count = int(clean["returned"].sum())
    order_count = int(len(clean))
    discounted_total = round(float(clean["discounted_order_value_inr"].sum()), 2)
    retained_total = round(float(clean["retained_revenue_inr"].sum()), 2)
    returned_total = round(float(clean["returned_order_value_inr"].sum()), 2)

    payment = _table_records(clean, "payment_method")
    categories = _table_records(clean, "category")
    products = _table_records(clean, ["product_id", "product_name", "category"])
    products.sort(
        key=lambda item: (
            item["returned_order_value_inr"],
            item["returned_order_count"],
            item["product_name"],
        ),
        reverse=True,
    )

    monthly_records: list[dict[str, Any]] = []
    for month, group in clean.groupby("month", sort=True):
        monthly_records.append({
            "month": str(month),
            "order_count": int(len(group)),
            "returned_order_count": int(group["returned"].sum()),
            "retained_revenue_inr": round(float(group["retained_revenue_inr"].sum()), 2),
            "returned_order_value_inr": round(
                float(group["returned_order_value_inr"].sum()), 2
            ),
        })

    ratings: list[dict[str, Any]] = []
    for returned, group in clean.groupby("returned", sort=True):
        ratings.append({
            "returned": bool(returned),
            "order_count": int(len(group)),
            "mean_rating": round(float(group["rating"].mean()), 2),
        })

    findings: dict[str, Any] = {
        "data_quality": quality,
        "metrics": {
            "clean_order_count": order_count,
            "returned_order_count": returned_count,
            "overall_return_rate_pct": percentage(returned_count, order_count),
            "discounted_order_value_inr": discounted_total,
            "retained_revenue_inr": retained_total,
            "returned_order_value_inr": returned_total,
            "returned_value_share_of_discounted_order_value_pct": percentage(
                returned_total, discounted_total
            ),
            "source_period": {
                "start": clean["order_date"].min().strftime("%Y-%m-%d"),
                "end": clean["order_date"].max().strftime("%Y-%m-%d"),
            },
            "revenue_definition": (
                "Selling price after discount; retained revenue excludes returned orders. "
                "No cost data is provided, so profit and margin are not calculated."
            ),
        },
        "breakdowns": {
            "payment_method_returns": payment,
            "category_returns": categories,
            "products_by_returned_value": products,
            "monthly_revenue": monthly_records,
            "rating_by_return_status": ratings,
        },
        "narrative": None,
    }
    findings["metric_catalog"] = build_metric_catalog(findings)
    return findings


def build_metric_catalog(findings: dict[str, Any]) -> list[dict[str, Any]]:
    """Create stable evidence keys that the narrator is allowed to cite."""
    catalog: list[dict[str, Any]] = []
    metrics = findings["metrics"]
    scalar_metrics = {
        "overall.clean_order_count": (metrics["clean_order_count"], "orders"),
        "overall.returned_order_count": (metrics["returned_order_count"], "orders"),
        "overall.return_rate_pct": (metrics["overall_return_rate_pct"], "percent"),
        "overall.discounted_order_value_inr": (
            metrics["discounted_order_value_inr"], "INR"
        ),
        "overall.retained_revenue_inr": (metrics["retained_revenue_inr"], "INR"),
        "overall.returned_order_value_inr": (metrics["returned_order_value_inr"], "INR"),
        "overall.returned_value_share_pct": (
            metrics["returned_value_share_of_discounted_order_value_pct"], "percent"
        ),
    }
    for key, (value, unit) in scalar_metrics.items():
        catalog.append({"key": key, "value": value, "unit": unit})

    for row in findings["breakdowns"]["payment_method_returns"]:
        key = row["payment_method"].lower()
        for field, unit in (
            ("order_count", "orders"),
            ("returned_order_count", "orders"),
            ("return_rate_pct", "percent"),
            ("returned_order_value_inr", "INR"),
        ):
            catalog.append({
                "key": f"payment.{key}.{field}",
                "value": row[field],
                "unit": unit,
            })
    for row in findings["breakdowns"]["category_returns"]:
        key = "".join(part.lower() for part in row["category"].split())
        for field, unit in (
            ("order_count", "orders"),
            ("returned_order_count", "orders"),
            ("return_rate_pct", "percent"),
            ("returned_order_value_inr", "INR"),
        ):
            catalog.append({
                "key": f"category.{key}.{field}",
                "value": row[field],
                "unit": unit,
            })
    for row in findings["breakdowns"]["products_by_returned_value"]:
        key = row["product_id"].lower()
        for field, unit in (
            ("order_count", "orders"),
            ("returned_order_count", "orders"),
            ("return_rate_pct", "percent"),
            ("returned_order_value_inr", "INR"),
        ):
            catalog.append({
                "key": f"product.{key}.{field}",
                "value": row[field],
                "unit": unit,
            })
    for row in findings["breakdowns"]["monthly_revenue"]:
        key = row["month"]
        for field, unit in (
            ("retained_revenue_inr", "INR"),
            ("returned_order_value_inr", "INR"),
            ("order_count", "orders"),
            ("returned_order_count", "orders"),
        ):
            catalog.append({
                "key": f"month.{key}.{field}",
                "value": row[field],
                "unit": unit,
            })
    return catalog


def run_analysis(database_path: Path) -> dict[str, Any]:
    if not database_path.exists():
        raise FileNotFoundError(
            f"SQLite database not found at {database_path}. "
            "Run the schema and seed commands in the README first."
        )
    with sqlite3.connect(database_path) as connection:
        raw = load_order_data(connection)
    clean, quality = prepare_clean_orders(raw)
    return build_findings(clean, quality)


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--db",
        type=Path,
        default=DEFAULT_DB,
        help=f"SQLite database path (default: {DEFAULT_DB})",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=FINDINGS_PATH,
        help=f"Findings JSON output (default: {FINDINGS_PATH})",
    )
    args = parser.parse_args()

    findings = run_analysis(args.db)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(findings, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    print(
        f"Analyzed {findings['data_quality']['source_order_count']} source rows; "
        f"removed {findings['data_quality']['duplicate_rows_removed']} duplicate rows; "
        f"wrote {findings['metrics']['clean_order_count']} clean orders to "
        f"{args.output.relative_to(REPO_ROOT) if args.output.is_relative_to(REPO_ROOT) else args.output}."
    )


if __name__ == "__main__":
    main()
