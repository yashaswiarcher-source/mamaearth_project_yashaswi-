#!/usr/bin/env python3
"""Generate a constrained narrative from the verified findings JSON."""

from __future__ import annotations

import argparse
import json
import os
import re
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any


REPO_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_FINDINGS = REPO_ROOT / "narrator" / "findings.json"

SYSTEM_PROMPT = """You are an operations and finance analyst writing a concise report.
Use only the supplied findings JSON. Do not invent facts, quantities, dates,
causes, comparisons, or recommendations that depend on unavailable data.
Return one JSON object with exactly these keys:
{
  "executive_summary": "string",
  "key_findings": [
    {"headline": "string", "observation": "string", "metric_keys": ["catalog key"]}
  ],
  "recommended_actions": [
    {"priority": "high|medium|low", "action": "string", "rationale": "string",
     "metric_keys": ["catalog key"]}
  ],
  "limitations": ["string"]
}
All metric_keys must be copied exactly from metric_catalog. Include no digits or
numeric values in prose; the UI/reporting layer can render the cited metric
values directly from metric_catalog. Do not claim profit or margin impact.
Recommendations must be framed as investigation or operational tests when the
available data does not establish causation. Return valid JSON only."""


def request_narrative(findings: dict[str, Any]) -> tuple[dict[str, Any], str]:
    api_key = (
        os.getenv("AI_INTEGRATIONS_OPENAI_API_KEY")
        or os.getenv("OPENAI_API_KEY")
    )
    if not api_key:
        raise RuntimeError(
            "No model credential is configured. Set OPENAI_API_KEY, or configure "
            "the Replit OpenAI AI Integration."
        )

    base_url = (
        os.getenv("AI_INTEGRATIONS_OPENAI_BASE_URL")
        or os.getenv("OPENAI_BASE_URL")
        or "https://api.openai.com/v1"
    ).rstrip("/")
    endpoint = (
        base_url
        if base_url.endswith("/chat/completions")
        else f"{base_url}/chat/completions"
    )
    model = os.getenv("NARRATIVE_MODEL", "gpt-5-mini")
    user_payload = {
        "metrics": findings.get("metrics"),
        "breakdowns": findings.get("breakdowns"),
        "metric_catalog": findings.get("metric_catalog"),
    }
    request_body = {
        "model": model,
        "max_completion_tokens": 8192,
        "response_format": {"type": "json_object"},
        "messages": [
            {"role": "system", "content": SYSTEM_PROMPT},
            {
                "role": "user",
                "content": json.dumps(user_payload, ensure_ascii=False),
            },
        ],
    }
    request = urllib.request.Request(
        endpoint,
        data=json.dumps(request_body).encode("utf-8"),
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=90) as response:
            response_data = json.loads(response.read().decode("utf-8"))
    except urllib.error.HTTPError as error:
        raise RuntimeError(f"Model request failed with HTTP {error.code}.") from None
    except urllib.error.URLError as error:
        raise RuntimeError(f"Could not reach the model endpoint: {error.reason}") from None

    try:
        content = response_data["choices"][0]["message"]["content"]
        narrative = json.loads(content)
    except (KeyError, IndexError, TypeError, json.JSONDecodeError) as error:
        raise RuntimeError("The model did not return the required JSON object.") from error

    validate_narrative(narrative, findings)
    return narrative, model


def validate_narrative(narrative: Any, findings: dict[str, Any]) -> None:
    if not isinstance(narrative, dict):
        raise ValueError("Narrative must be a JSON object.")
    required = {
        "executive_summary",
        "key_findings",
        "recommended_actions",
        "limitations",
    }
    if set(narrative) != required:
        raise ValueError("Narrative JSON has missing or unexpected top-level fields.")
    if not isinstance(narrative["executive_summary"], str):
        raise ValueError("executive_summary must be a string.")
    if not isinstance(narrative["key_findings"], list) or not narrative["key_findings"]:
        raise ValueError("key_findings must be a non-empty list.")
    if (
        not isinstance(narrative["recommended_actions"], list)
        or not narrative["recommended_actions"]
    ):
        raise ValueError("recommended_actions must be a non-empty list.")
    if not isinstance(narrative["limitations"], list):
        raise ValueError("limitations must be a list.")

    catalog_keys = {
        item["key"] for item in findings.get("metric_catalog", [])
        if isinstance(item, dict) and isinstance(item.get("key"), str)
    }

    def check_prose(text: Any, field: str) -> None:
        if not isinstance(text, str) or not text.strip():
            raise ValueError(f"{field} must be a non-empty string.")
        if re.search(r"(?<![A-Za-z])(?:₹\s*)?[-+]?\d[\d,]*(?:\.\d+)?%?", text):
            raise ValueError(
                f"{field} contains a numeric claim. Keep prose qualitative and "
                "cite metric keys instead."
            )

    check_prose(narrative["executive_summary"], "executive_summary")
    for index, item in enumerate(narrative["key_findings"]):
        if not isinstance(item, dict) or set(item) != {"headline", "observation", "metric_keys"}:
            raise ValueError(f"key_findings[{index}] has an invalid shape.")
        check_prose(item["headline"], f"key_findings[{index}].headline")
        check_prose(item["observation"], f"key_findings[{index}].observation")
        validate_metric_keys(item["metric_keys"], catalog_keys, f"key_findings[{index}]")

    for index, item in enumerate(narrative["recommended_actions"]):
        if not isinstance(item, dict) or set(item) != {
            "priority", "action", "rationale", "metric_keys"
        }:
            raise ValueError(f"recommended_actions[{index}] has an invalid shape.")
        if item["priority"] not in {"high", "medium", "low"}:
            raise ValueError(f"recommended_actions[{index}].priority is invalid.")
        check_prose(item["action"], f"recommended_actions[{index}].action")
        check_prose(item["rationale"], f"recommended_actions[{index}].rationale")
        validate_metric_keys(
            item["metric_keys"], catalog_keys, f"recommended_actions[{index}]"
        )

    for index, limitation in enumerate(narrative["limitations"]):
        check_prose(limitation, f"limitations[{index}]")


def validate_metric_keys(keys: Any, catalog: set[str], field: str) -> None:
    if not isinstance(keys, list) or not keys:
        raise ValueError(f"{field}.metric_keys must be a non-empty list.")
    if any(not isinstance(key, str) or key not in catalog for key in keys):
        raise ValueError(f"{field} refers to a metric key not present in findings.json.")


def generate(findings_path: Path) -> None:
    if not findings_path.exists():
        raise FileNotFoundError(
            f"Findings file not found at {findings_path}. "
            "Run analysis/clean_and_eda.py first."
        )
    findings = json.loads(findings_path.read_text(encoding="utf-8"))
    if not findings.get("metrics") or not findings.get("metric_catalog"):
        raise ValueError("findings.json is missing computed metrics or metric_catalog.")

    narrative, model = request_narrative(findings)
    findings["narrative"] = {
        "provider": "OpenAI-compatible Chat Completions",
        "model": model,
        "content": narrative,
    }
    temporary_path = findings_path.with_suffix(".json.tmp")
    temporary_path.write_text(
        json.dumps(findings, indent=2, ensure_ascii=False) + "\n",
        encoding="utf-8",
    )
    temporary_path.replace(findings_path)
    print(f"Generated and validated the narrative in {findings_path}.")


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--findings", type=Path, default=DEFAULT_FINDINGS)
    args = parser.parse_args()
    generate(args.findings)


if __name__ == "__main__":
    main()
